# faiqgcp

Frequently asked interview questions on GCP